package com.cs442.ssonawa1.myfoodorder;

import android.app.Activity;
import android.app.Fragment;
import android.app.ListFragment;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by sneha on 10/1/2016.
 */
public class MenuFragment extends Fragment {
    public ArrayAdapter<Item> adapterItems;
    public ListView listView;
    //private OnListItemSelectedListener listener;
    ArrayList<Item> items;
    double dblTotal = 0;
    TextView txtTotalPrice;

    /*public interface OnListItemSelectedListener {
        public void onItemSelected(Item item);
    }*/

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        /*if (activity instanceof OnListItemSelectedListener) {
            listener = (OnListItemSelectedListener) activity;
        } else {
            throw new ClassCastException(
                    activity.toString()
                            + " must implement MenuFragment.OnListItemSelectedListener");
        }*/
    }




    @Override
    public void onCreate(Bundle savedInstanceState){
      super.onCreate(savedInstanceState);
        items=Item.getItems();
        adapterItems = new ArrayAdapter<Item>(getActivity(),
                android.R.layout.simple_list_item_activated_1, items);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view=inflater.inflate(R.layout.fragment_list, container, false);
        listView=(ListView)view.findViewById(R.id.list);
        listView.setAdapter(adapterItems);
        txtTotalPrice=(TextView)view.findViewById(R.id.totalprice);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Item item=adapterItems.getItem(position);

                Intent i = new Intent(getActivity(), MenuDetailsActivity.class);
                // Embed the serialized item
                i.putExtra("item", item);
                // Start the activity
                Log.d("hi clicked", "hi clicked");
                startActivityForResult(i,0);
                //listener.onItemSelected(item);
            }
        });
        return view;
    }

    public void onActivityResult(int RequestCode, int ResultCode, Intent data){

        switch (RequestCode){
            case 0:
                if(ResultCode==0){
                    Item z= (Item) data.getSerializableExtra("modified_list");
                    String s=z.getQuantity();
                    dblTotal = 0;
                    for (int i=0;i<items.size();i++)
                    {
                        if (items.get(i).getId().equals(z.getId()))
                        {
                            items.get(i).setQuantity(s);
                        }

                        dblTotal = dblTotal + (Double.parseDouble(items.get(i).getQuantity())
                                * Double.parseDouble(items.get(i).getPrice()));
                    }
                    Log.d("s", s);
                    adapterItems.notifyDataSetChanged();
                    txtTotalPrice.setText("$ "+Double.toString(dblTotal));
                    /*
                    MenuFragment c = new MenuFragment();
                    c.adapterItems = new ArrayAdapter<Item>(this,
                            android.R.layout.simple_list_item_activated_1, arrlstTemp);
                    c.items = arrlstTemp;
                    c.adapterItems.notifyDataSetChanged();*/
                }
        }

    }

    public void setActivateOnItemClick(boolean activateOnItemClick) {
        // When setting CHOICE_MODE_SINGLE, ListView will automatically
        // give items the 'activated' state when touched.
        listView.setChoiceMode(
                activateOnItemClick ? ListView.CHOICE_MODE_SINGLE
                        : ListView.CHOICE_MODE_NONE);
    }

    public void updateAdapter (ArrayList<Item> arrlstItems)
    {
        if (arrlstItems!=null) {
            items = arrlstItems;
            adapterItems.notifyDataSetChanged();
        }
    }

}
