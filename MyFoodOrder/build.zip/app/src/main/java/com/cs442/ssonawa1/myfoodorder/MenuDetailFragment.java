package com.cs442.ssonawa1.myfoodorder;

import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Created by sneha on 10/1/2016.
 */
public class MenuDetailFragment extends Fragment implements View.OnClickListener {
    private Item item;
   // private List<Item> items;
    Button btn;
    EditText tvquant;
    private View view;
    TextView tvTitle, tvBody, tvId, tvdesc;

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        item=(Item)getArguments().getSerializable("item");
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        view=inflater.inflate(R.layout.frag_new, container,false);
         tvTitle = (TextView) view.findViewById(R.id.title);
         tvBody = (TextView) view.findViewById(R.id.price);
         tvId=(TextView)view.findViewById(R.id.idtitle);
         tvdesc=(TextView)view.findViewById(R.id.description);
        tvquant=(EditText)view.findViewById(R.id.editquant);
        btn=(Button)view.findViewById(R.id.backbutton);
        btn.setText("New Button");
        tvTitle.setText(item.getTitle());
        tvBody.setText("$ "+item.getPrice());
        tvId.setText(item.getId()+".");
        tvdesc.setText(item.getDescription());
        btn.setOnClickListener(this);  /*{
           @Override
            public void onClick(View v) {
                Log.d("Hello 1", "Hello 1");

                int quantity=0;
                quantity=Integer.parseInt(tvquant.getText().toString());
                Log.d("Hello","Hello");
                Log.d("quantity", Integer.toString(quantity));
            }
        });*/

        return view;
    }
   @Override
    public void onClick(View v) {
       Log.d("Hi","Hi");
       int quantity=0;
        quantity=Integer.parseInt(tvquant.getText().toString());
        item.setQuantity(Integer.toString(quantity));
       Intent intent=this.getActivity().getIntent();
        intent.putExtra("modified_list",item);
        this.getActivity().setResult(0,intent);
        this.getActivity().finish();
        Log.d("Hello","Hello");
        Log.d("quantity", Integer.toString(quantity));
        }


    public static MenuDetailFragment newInstance(Item item) {
        MenuDetailFragment fragmentDemo = new MenuDetailFragment();
        Bundle args = new Bundle();
        args.putSerializable("item", item);
        fragmentDemo.setArguments(args);
        return fragmentDemo;
    }
}
